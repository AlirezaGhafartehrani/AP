package com.university;

public class University {
    public Department[] getDepartments(){
        return null;
    }

    public void addDepartment(Department department){ }

    public void removeDepartment(Department department){ }
}
