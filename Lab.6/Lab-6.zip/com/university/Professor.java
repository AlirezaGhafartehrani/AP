package com.university;

public class Professor {

    public Professor(Department department, String name) {

    }

    public Department getDepartment() {
        return null;
    }

    public String getName() {
        return null;
    }

    public Course[] getCourses() {
        return null;
    }
}
