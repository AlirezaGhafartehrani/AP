package com.university;

public class Department {

    public Department(String name) {

    }

    public String getName(){
        return null;
    }

    public void addStudent(Student student){

    }

    public Student[] getStudents(){
        return null;
    }

    public void removeStudent(Student student){

    }

    public void addCourse(Course course){

    }

    public Course[] getCourses(){
        return null;
    }

    public void removeCourse(Course course){

    }

    public void addProfessor(Professor student){

    }

    public Professor[] getProfessors(){
        return null;
    }

    public void removeProfessor(Professor professor){

    }

}
