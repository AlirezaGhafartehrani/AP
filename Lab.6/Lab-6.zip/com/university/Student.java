package com.university;

public class Student {

    public Student(String name, String ID, String major, Department department) {

    }

    public String getName() {
        return null;
    }

    public String getID() {
        return null;
    }

    public String getMajor() {
        return null;
    }

    public Department getDepartment() {
        return null;
    }

    public Course[] getCourses() {
        return null;
    }

    public void addCourse(Course course){

    }
}
