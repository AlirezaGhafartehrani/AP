package com.university;

public class Course {

    public Course(String ID, String name, Department department, Professor professor, int credit) {

    }

    public String getID(){
        return null;
    }

    public Department getDepartment(){
        return null;
    }

    public String getName() {
        return null;
    }

    public Student[] getStudents() {
        return null;
    }

    public Professor getProfessor() {
        return null;
    }

    public int getCredit() {
        return 0;
    }

    public void enrollStudent(Student student){

    }

}
